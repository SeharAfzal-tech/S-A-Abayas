let cart = [];

function addToCart(name, price) {
  cart.push({ name, price });
  displayCart();
}

function removeItem(index) {
  cart.splice(index, 1);
  displayCart();
}

function displayCart() {
  let list = document.getElementById("cartItems");
  list.innerHTML = "";

  let total = 0;

  cart.forEach((item, index) => {
    total += item.price;

    let li = document.createElement("li");
    li.innerHTML = `
      ${item.name} - $${item.price}
      <button onclick="removeItem(${index})">❌</button>
    `;
    list.appendChild(li);
  });

  document.getElementById("total").innerText = total;
}

function placeOrder() {
  if (cart.length === 0) {
    alert("🛒 Cart is empty!");
    return;
  }

  let name = document.getElementById("name").value.trim();
  let email = document.getElementById("email").value.trim();
  let phone = document.getElementById("phone").value.trim();
  let address = document.getElementById("address").value.trim();

  // ❌ EMPTY FIELDS CHECK
  if (!name || !email || !phone || !address) {
    alert("⚠️ Please fill all fields!");
    return;
  }

  // ❌ NAME VALIDATION (letters only)
  let namePattern = /^[A-Za-z ]+$/;
  if (!namePattern.test(name)) {
    alert("⚠️ Please enter a valid name (letters only)!");
    return;
  }

  // ❌ EMAIL VALIDATION
  let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    alert("⚠️ Please enter a valid email address!");
    return;
  }

  // ❌ PHONE VALIDATION (digits only, 10-15 length)
  let phonePattern = /^[0-9]{10,15}$/;
  if (!phonePattern.test(phone)) {
    alert("⚠️ Please enter a valid phone number!");
    return;
  }

  // ✅ SUCCESS ORDER
  alert(
    "🎉 Order Placed Successfully!\n\n" +
    "Name: " + name + "\n" +
    "Email: " + email + "\n" +
    "Phone: " + phone + "\n" +
    "Address: " + address + "\n\n" +
    "Total Items: " + cart.length
  );

  // RESET
  cart = [];
  displayCart();

  document.getElementById("name").value = "";
  document.getElementById("email").value = "";
  document.getElementById("phone").value = "";
  document.getElementById("address").value = "";
}
function searchProducts() {
  let input = document.getElementById("searchBar").value.toLowerCase();
  let cards = document.querySelectorAll(".card");

  cards.forEach(card => {
    let text = card.innerText.toLowerCase();

    if (text.includes(input)) {
      card.style.display = "block";
    } else {
      card.style.display = "none";
    }
  });
}

function openPopup(name, price) {
  cart.push({ name, price });
  displayCart();

  alert("⚡ Item added for quick checkout!");
  document.getElementById("cart").scrollIntoView({ behavior: "smooth" });
}